package com.app.service;

import java.util.List;

import com.app.pojos.UserDetails;

public interface AdminService 
{

	List<UserDetails> listUsers();
}
