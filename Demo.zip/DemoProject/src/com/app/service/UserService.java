package com.app.service;

import java.util.List;

import com.app.pojos.User;
import com.app.pojos.UserDetails;


public interface UserService 
{
	public User validateUser(String email,String pass);
	public User registerUser(User user);
	public List<String> getRoles();
	public User findByEmail(String email);
	public int generateOtp();
	public User getUserById(int id);
	public void updatePassword(User userPojo);
	public String domicileUser(UserDetails user);
	public List<UserDetails> getRegUser();
	public void setStatus(int id);
	public UserDetails getStatuss(int id);
}
