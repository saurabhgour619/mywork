package com.app.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.UserDao;
import com.app.pojos.User;
import com.app.pojos.UserDetails;


@Service
@Transactional
public class UserServiceImpl implements UserService 
{
	@Autowired
	private UserDao dao;
	
	@Override
	public User validateUser(String email, String pass) {
		System.out.println("inside insdde");
		return dao.validateUser(email, pass);
	}

	@Override
	public User registerUser(User user) {
		System.out.println("dao"+user.getEmail());
		return dao.registerUser(user,user.getUserRole().getRole());
	}
	
	@Override
	public String domicileUser(UserDetails ud) {		
		this.dao.domicileUser(ud);
		return "success";
	}
	
	@Override
	public List<String> getRoles() {
		return dao.getRoles();
	}

	@Override
	public List<UserDetails> getRegUser() {
		return dao.getRegUser();
	}
	
	@Override
	public User findByEmail(String email) {
		return dao.findByEmail(email);
	}

	@Override
	public int generateOtp() 
	{
		Random random = new Random();
		int num = random.nextInt(99999) + 99999;
		if (num < 100000 || num > 999999) 
		{
			num = random.nextInt(99999) + 99999;
			if (num < 100000 || num > 999999)
			{
				System.out.println("Unable to generate PIN at this time..");
			}
		}
		return num;
		
	}

	@Override
	public User getUserById(int id) {
		return dao.getUserById(id);
	}

	@Override
	public void updatePassword(User userPojo) {
		dao.updatePassword(userPojo);
		
	}

	@Override
	public void setStatus(int id) {
		dao.setStatus(id);
		
	}

	@Override
	public UserDetails getStatuss(int id) {
		return dao.getStatuss(id);
	}
	
}