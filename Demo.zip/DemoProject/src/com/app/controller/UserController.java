package com.app.controller;

import java.io.IOException;
import java.util.List;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.User;
import com.app.pojos.UserDetails;
import com.app.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService service;

	@Autowired
	private JavaMailSender mailSender;

	public UserController() {
		System.out.println("Inside User Controller");
	}

	@GetMapping("/login")
	public String showLoginForm(User user) {
		System.out.println("inside showLoginForm");
		return "login";
	}

	@PostMapping("/login")
	public String processLoginForm(User user, HttpSession hs, Model map) {
		System.out.println("inside processLoginForm");
		User validUser;
		try {
			System.out.println("validUser");
			validUser = service.validateUser(user.getEmail(), user.getPassword());
			System.out.println(validUser.getEmail());
			System.out.println(validUser.getPassword());
			byte[] imgContent = validUser.getUserImg();
			String url = "data:image/jpeg;base64," + Base64.encode(imgContent);
			System.out.println("------------" + url);
			// map.addAttribute("url",url);
			hs.setAttribute("url", url);
			if (validUser != null) {
				System.out.println(validUser.getEmail());
				hs.setAttribute("validUser", validUser);
				User u = (User) hs.getAttribute("validUser");
				System.out.println(u.toString());
				return "redirect:dashboard";
			}
		} catch (NoResultException e) {
			map.addAttribute("msg", "Invaid login credentials");
			e.printStackTrace();
		}
		return "login";
	}

	@GetMapping("/register")
	public String showRegisterForm(User user, Model map) {

		List<String> roles = service.getRoles();
		map.addAttribute("roleList", roles);
		return "register";
	}

	@PostMapping("/register")
	public String processRegisterForm(User user, RedirectAttributes flashMap, @RequestParam MultipartFile imageUpload)
			throws IOException {
		if (imageUpload != null) {

			System.out.println(imageUpload.getOriginalFilename());
			user.setUserImg(imageUpload.getBytes());
			flashMap.addFlashAttribute("msg",
					"Registration done with RegID : " + service.registerUser(user).getUserId());
		}
		return "redirect:login";
	}

	@GetMapping("/domicile")
	public String showDomicleForm(UserDetails user, Model map, HttpSession hs) {
		System.out.println("inside showDomicileForm");
		User u = (User) hs.getAttribute("validUser");
		map.addAttribute("user", u);
		return "domicile";
	}

	@GetMapping("/index")
	public String index(UserDetails user, Model map) {
		return "index";
	}

	@PostMapping("/domicile")
	public String processDomicleForm(UserDetails user, HttpSession hs, RedirectAttributes flashMap,
			@RequestParam MultipartFile imageUpload1, @RequestParam MultipartFile imageUpload2,
			@RequestParam MultipartFile imageUpload3, @RequestParam MultipartFile imageUpload4,
			@RequestParam MultipartFile imageUpload5, @RequestParam MultipartFile imageUpload6) throws IOException {
		User u = (User) hs.getAttribute("validUser");
		System.out.println("Inside processDomicileForm");
		user.setAadharcard(imageUpload1.getBytes());
		user.setElectricitybill(imageUpload2.getBytes());
		user.setPancard(imageUpload3.getBytes());
		user.setPassport(imageUpload4.getBytes());
		user.setRationcard(imageUpload5.getBytes());
		user.setWaterbill(imageUpload6.getBytes());
		user.setUser(u);
		String regStatus = service.domicileUser(user);
		System.out.println(user.getWaterbillNo().toString());
		System.out.println("*********************" + regStatus);
		if (regStatus.equals("success"))
			return "user/dashboard";
		return "user/dashboard";
	}

	@GetMapping("/logout")
	public String logoutUser(HttpSession hs) {
		hs.invalidate();
		return "redirect:login";
	}

	@GetMapping("/home")
	public String homePage(HttpSession hs) {
		hs.invalidate();
		return "admin";
	}

	@GetMapping("/admin")
	public String adminLogin(HttpSession hs) {
		System.out.println("admin");
		hs.invalidate();
		return "admin";
	}

	@GetMapping("/forgot")
	public String showForgotPassword() {
		return "forgotPassword";
	}

	@PostMapping("/forgot")
	public String processForgotPassword(HttpServletRequest request, Model map, HttpSession hs) {
		String em = request.getParameter("email");
		User user;
		try {
			user = service.findByEmail(em);
			hs.setAttribute("user", user);
			if (user != null) {
				int otp = service.generateOtp();
				hs.setAttribute("OTP", otp);
				String msg = "Your one time password for forgot password is = " + otp;
				SimpleMailMessage mailMessage = new SimpleMailMessage();
				mailMessage.setTo(user.getEmail());
				mailMessage.setSubject("One Time Password");
				mailMessage.setText(msg);
				try {
					mailSender.send(mailMessage);
				} catch (MailException e) {
					System.out.println("inside mail exception");
					e.printStackTrace();
				}
				return "otp";
			}
		} catch (NoResultException e) {
			map.addAttribute("msg", "Please enter valid email address");
			e.printStackTrace();
		}
		return "forgotPassword";
	}

	@PostMapping("/confirmOtp")
	public String confirmOtp(HttpServletRequest request, HttpSession hs) {
		int otp = (int) hs.getAttribute("OTP");
		int formOtp = Integer.parseInt(request.getParameter("otp"));
		if (otp == formOtp) {
			User user = (User) hs.getAttribute("user");
			String role = user.getUserRole().getRole();
			if (role.equals("BUYER"))
				return "buyer/dashboard";
			else
				return "admin/dashboard";
		} else
			hs.setAttribute("msg", "Enter valid one time password");
		return "otp";
	}

	@GetMapping("/changepass")
	public String showChangePasswordForm() {
		return "changePassword";
	}

	@PostMapping("/changepass")
	public String processChangePasswordForm(@RequestParam int id, HttpServletRequest request, HttpSession hs) {
		User userPojo = (User) hs.getAttribute("validUser");
		User user = service.getUserById(id);
		String pass = request.getParameter("confirmPass");
		user.setPassword(pass);
		service.updatePassword(user);
		return "redirect:/dashboard";
	}

	@GetMapping("/dashboard")
	public String showDashboard(HttpSession hs, Model map) {
		User validUser;
		System.out.println("in showDashboard");
		System.out.println(hs.getAttribute("validUser"));
		User userPojo = (User) hs.getAttribute("validUser");
		System.out.println("*********************************" + userPojo.toString());

		String role = userPojo.getUserRole().getRole();
		if (role.equals("admin")) {
			List<UserDetails> ulist = service.getRegUser();
			map.addAttribute("udetlist", ulist);
			return "admin/dashboard";
		} else
			return "user/dashboard";
	}

	@GetMapping("/personaldetails")
	public String showPersonalDashboard(HttpSession hs, Model map) {
		User validUser;
		System.out.println("in showPersonalDashboard");
		System.out.println(hs.getAttribute("validUser"));
		User userPojo = (User) hs.getAttribute("validUser");
		System.out.println("*********************************" + userPojo.toString());

		String role = userPojo.getUserRole().getRole();
		List<UserDetails> ulist = service.getRegUser();
		map.addAttribute("udetlist", ulist);
		return "admin/personaldetails";
	}

	@GetMapping("/addressdetails")
	public String showAddressDashboard(HttpSession hs, Model map) {
		User validUser;
		System.out.println("in showAddressDashboarddashboard");
		System.out.println(hs.getAttribute("validUser"));
		User userPojo = (User) hs.getAttribute("validUser");
		System.out.println("*********************************" + userPojo.toString());

		String role = userPojo.getUserRole().getRole();
		List<UserDetails> ulist = service.getRegUser();
		map.addAttribute("udetlist", ulist);
		return "admin/addressdetails";
	}

	@GetMapping("/documentdetails")
	public String showDocumentDashboard(HttpSession hs, Model map) {
		User validUser;
		System.out.println("in showDocumentDashboard");
		System.out.println(hs.getAttribute("validUser"));
		User userPojo = (User) hs.getAttribute("validUser");
		System.out.println("*********************************" + userPojo.toString());
		List<UserDetails> ulist = service.getRegUser();
		for (UserDetails userDetails : ulist) {
			byte[] imgContentaadharcard = userDetails.getAadharcard();
			byte[] imgContentpancard = userDetails.getPancard();
			byte[] imgContentelectricity = userDetails.getElectricitybill();
			byte[] imgcontentpassport = userDetails.getPassport();
			byte[] imgcontentrationcard = userDetails.getRationcard();
			byte[] imgContentwaterbill = userDetails.getWaterbill();

			String url_aadhar = "data:image/jpeg;base64," + Base64.encode(imgContentaadharcard);
			String url_electricity = "data:image/jpeg;base64," + Base64.encode(imgContentelectricity);
			String url_pancard = "data:image/jpeg;base64," + Base64.encode(imgContentpancard);
			String url_ration = "data:image/jpeg;base64," + Base64.encode(imgcontentrationcard);
			String url_water = "data:image/jpeg;base64," + Base64.encode(imgContentwaterbill);
			String url_passport = "data:image/jpeg;base64," + Base64.encode(imgcontentpassport);

			userDetails.setUrl_pancard(url_pancard);
			userDetails.setUrl_aadhar(url_aadhar);
			userDetails.setUrl_electricity(url_electricity);
			userDetails.setUrl_passport(url_passport);
			userDetails.setUrl_ration(url_ration);
			userDetails.setUrl_water(url_water);
		}

		String role = userPojo.getUserRole().getRole();
		map.addAttribute("udetlist", ulist);
		return "admin/documentdetails";
	}

	@GetMapping("/approve")
	public String Status(@RequestParam int id, HttpSession hs, Model map) {
		System.out.println("id in status" + id);
		service.setStatus(id);
		return "/index";
	}

	@GetMapping("/status")
	public String checkStatus(@RequestParam int id, HttpSession hs, Model map) {
			System.out.println("id in status" + id);
			UserDetails ud = service.getStatuss(id);
			map.addAttribute("ud", ud);
			System.out.println("status in check is" + ud.getStatus());
			return "user/status";
	}
}