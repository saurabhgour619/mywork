package com.app.dao;

import java.util.List;

import com.app.pojos.User;
import com.app.pojos.UserDetails;


public interface UserDao 
{
	public User validateUser(String email,String password);
	public User registerUser(User user,String roleName);
	public List<String> getRoles();
	public User findByEmail(String email);
	public User getUserById(int id);
	public void updatePassword(User userPojo);
	public Integer domicileUser(UserDetails ud);
	public List<UserDetails> getRegUser();
	public void setStatus(Integer id);
	public UserDetails getStatuss(Integer id);
}
