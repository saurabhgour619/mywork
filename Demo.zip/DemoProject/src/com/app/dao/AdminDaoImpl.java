package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.UserDetails;

@Repository
public class AdminDaoImpl implements AdminDao 
{
	@Autowired
	private SessionFactory sf;
	
	@Override
	public List<UserDetails> listUsers() {
		String jpql = "select v from UserDetails v";
		return sf.getCurrentSession().createQuery(jpql, UserDetails.class).getResultList();
	}
	

}
