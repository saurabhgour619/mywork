package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.app.pojos.User;
import com.app.pojos.UserDetails;
import com.app.pojos.UserRole;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public User validateUser(String email, String pass) {
		System.out.println("validateuser inside");
		String str = "select u from User u where u.email=:em and u.password=:pass";
		System.out.println();
		return sf.getCurrentSession().createQuery(str, User.class).setParameter("em", email).setParameter("pass", pass)
				.getSingleResult();

	}

	@Override
	public User registerUser(User user, String roleName) {
		String hql = "select r from UserRole r where r.role=:rm";
		UserRole role = (UserRole) sf.getCurrentSession().createQuery(hql).setParameter("rm", roleName)
				.getSingleResult();
		role.addUser(user);
		return user;
	}

	@Override
	public List<String> getRoles() {
		String str = "select distinct u.role from UserRole u";
		return sf.getCurrentSession().createQuery(str, String.class).getResultList();
	}

	@Override
	public User findByEmail(String email) {
		String str = "select u from User u where u.email=:em";
		return sf.getCurrentSession().createQuery(str, User.class).setParameter("em", email).getSingleResult();
	}

	@Override
	public User getUserById(int id) {
		return sf.getCurrentSession().get(User.class, id);
	}

	@Override
	public void updatePassword(User userPojo) {
		sf.getCurrentSession().update(userPojo);

	}

	@Override
	public Integer domicileUser(UserDetails user) {
		return (Integer) sf.getCurrentSession().save(user);
	}

	@Override
	public List<UserDetails> getRegUser() {
		String str = "select u from UserDetails u";
		return sf.getCurrentSession().createQuery(str, UserDetails.class).getResultList();

	}

	@Override
	public void setStatus(Integer id) {
		UserDetails ud = sf.getCurrentSession().get(UserDetails.class, id);
		ud.setStatus("approved");

	}

	@Override
	public UserDetails getStatuss(Integer id) {
		String query = "select ud from UserDetails ud where ud.user.userId=:id";
		UserDetails ud = sf.getCurrentSession().createQuery(query, UserDetails.class).setParameter("id", id)
				.getSingleResult();
		return ud;
	}
}
