package com.app.pojos;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="USERS_DETAILS")
public class UserDetails 
{
	private Integer appl_id;
	private String father_name,mother_name;
	private String occupation;
	private String caste,subcaste;
	private String mothertongue;
	private String birthplace;
	private String address1,address2;
	private String state,district,country,village;
	private Integer pincode;
	private String pancardNo;
	private String aadharcardNo;
	private String passportNo;
	private String rationcardNo;
	private String waterbillNo;
	private String electricitybillNo;
	private byte[] pancard;
	private byte[] aadharcard;
	private byte[] passport;
	private byte[] rationcard;
	private byte[] waterbill;
	private byte[] electricitybill;
	private User user;
	private String url_pancard;
	private String url_aadhar;
	private String url_passport;
	private String url_ration;
	private String url_water;
	private String url_electricity;
	private String status;
	
	public UserDetails() {
		// TODO Auto-generated constructor stub
	}
		public UserDetails(Integer appl_id, String father_name, String mother_name, String occupation, String caste,
			String subcaste, String mothertongue, String birthplace, String address1, String address2, String state,
			String district, String country, String village, Integer pincode, String pancardNo, String aadharcardNo,
			String passportNo, String rationcardNo, String waterbillNo, String electricitybillNo, byte[] pancard,
			byte[] aadharcard, byte[] passport, byte[] rationcard, byte[] waterbill, byte[] electricitybill, User user,
			String url_pancard, String url_aadhar, String url_passport, String url_ration, String url_water,
			String url_electricity, String status) {
		super();
		this.appl_id = appl_id;
		this.father_name = father_name;
		this.mother_name = mother_name;
		this.occupation = occupation;
		this.caste = caste;
		this.subcaste = subcaste;
		this.mothertongue = mothertongue;
		this.birthplace = birthplace;
		this.address1 = address1;
		this.address2 = address2;
		this.state = state;
		this.district = district;
		this.country = country;
		this.village = village;
		this.pincode = pincode;
		this.pancardNo = pancardNo;
		this.aadharcardNo = aadharcardNo;
		this.passportNo = passportNo;
		this.rationcardNo = rationcardNo;
		this.waterbillNo = waterbillNo;
		this.electricitybillNo = electricitybillNo;
		this.pancard = pancard;
		this.aadharcard = aadharcard;
		this.passport = passport;
		this.rationcard = rationcard;
		this.waterbill = waterbill;
		this.electricitybill = electricitybill;
		this.user = user;
		this.url_pancard = url_pancard;
		this.url_aadhar = url_aadhar;
		this.url_passport = url_passport;
		this.url_ration = url_ration;
		this.url_water = url_water;
		this.url_electricity = url_electricity;
		this.status = status;
	}
		@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getAppl_id() {
		return appl_id;
	}

	public void setAppl_id(Integer appl_id) {
		this.appl_id = appl_id;
	}

	@OneToOne
	@JoinColumn(name="fk_id")
	public User getUser() {
		return user;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getMothertongue() {
		return mothertongue;
	}

	public void setMothertongue(String mothertongue) {
		this.mothertongue = mothertongue;
	}

	public String getBirthplace() {
		return birthplace;
	}
	
	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getAadharcardNo() {
		return aadharcardNo;
	}

	public void setAadharcardNo(String aadharcardNo) {
		this.aadharcardNo = aadharcardNo;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getRationcardNo() {
		return rationcardNo;
	}

	public void setRationcardNo(String rationcardNo) {
		this.rationcardNo = rationcardNo;
	}

	public String getWaterbillNo() {
		return waterbillNo;
	}

	public void setWaterbillNo(String waterbillNo) {
		this.waterbillNo = waterbillNo;
	}

	public String getElectricitybillNo() {
		return electricitybillNo;
	}

	public void setElectricitybillNo(String electricitybillNo) {
		this.electricitybillNo = electricitybillNo;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getFather_name() {
		return father_name;
	}

	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}

	public String getMother_name() {
		return mother_name;
	}

	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}

	public String getCaste() {
		return caste;
	}

	public void setCaste(String caste) {
		this.caste = caste;
	}

	public String getSubcaste() {
		return subcaste;
	}

	public void setSubcaste(String subcaste) {
		this.subcaste = subcaste;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public byte[] getPancard() {
		return pancard;
	}

	public void setPancard(byte[] pancard) {
		this.pancard = pancard;
	}

	public byte[] getAadharcard() {
		return aadharcard;
	}

	public void setAadharcard(byte[] aadharcard) {
		this.aadharcard = aadharcard;
	}

	public byte[] getPassport() {
		return passport;
	}

	public void setPassport(byte[] passport) {
		this.passport = passport;
	}

	public byte[] getRationcard() {
		return rationcard;
	}

	public void setRationcard(byte[] rationcard) {
		this.rationcard = rationcard;
	}

	public byte[] getWaterbill() {
		return waterbill;
	}

	public void setWaterbill(byte[] waterbill) {
		this.waterbill = waterbill;
	}

	public byte[] getElectricitybill() {
		return electricitybill;
	}

	public void setElectricitybill(byte[] electricitybill) {
		this.electricitybill = electricitybill;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUrl_pancard() {
		return url_pancard;
	}

	public void setUrl_pancard(String url_pancard) {
		this.url_pancard = url_pancard;
	}

	public String getUrl_aadhar() {
		return url_aadhar;
	}

	public void setUrl_aadhar(String url_aadhar) {
		this.url_aadhar = url_aadhar;
	}

	public String getUrl_passport() {
		return url_passport;
	}

	public void setUrl_passport(String url_passport) {
		this.url_passport = url_passport;
	}

	public String getUrl_ration() {
		return url_ration;
	}

	public void setUrl_ration(String url_ration) {
		this.url_ration = url_ration;
	}

	public String getUrl_water() {
		return url_water;
	}

	public void setUrl_water(String url_water) {
		this.url_water = url_water;
	}

	public String getUrl_electricity() {
		return url_electricity;
	}

	public void setUrl_electricity(String url_electricity) {
		this.url_electricity = url_electricity;
	}

	
	@Column
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "UserDetails [appl_id=" + appl_id + ", father_name=" + father_name + ", mother_name=" + mother_name
				+ ", occupation=" + occupation + ", caste=" + caste + ", subcaste=" + subcaste + ", mothertongue="
				+ mothertongue + ", birthplace=" + birthplace + ", address1=" + address1 + ", address2=" + address2
				+ ", country=" + country + ", state=" + state + ", district=" + district + ", village=" + village
				+ ", pincode=" + pincode + ", pancardNo=" + pancardNo + ", aadharcardNo=" + aadharcardNo
				+ ", passportNo=" + passportNo + ", rationcardNo=" + rationcardNo + ", waterbillNo=" + waterbillNo
				+ ", electricitybillNo=" + electricitybillNo + ", pancard=" + Arrays.toString(pancard) + ", aadharcard="
				+ Arrays.toString(aadharcard) + ", passport=" + Arrays.toString(passport) + ", rationcard="
				+ Arrays.toString(rationcard) + ", waterbill=" + Arrays.toString(waterbill) + ", electricitybill="
				+ Arrays.toString(electricitybill) + "]";
	}

}
