package com.app.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "T_DOCUMENTS")
public class Documents {
	private Integer documentId;
	private String adhaarCard;
	private String panCard;
	private String electricityBill;
	private String drivingLicense;
	private String voterId;
	private User user;
	private byte[] userImgAadhaarCard;
	private byte[] userImgPanCard;
	private byte[] userImgElectricityBill;
	private byte[] userImgDrivingLicense;
	private byte[] userImgVoterId;

	public Documents() {

	}

	public Documents(Integer documentId, String adhaarCard, String panCard, String electricityBill,
			String drivingLicense, String voterId, User user) {
		super();
		this.documentId = documentId;
		this.adhaarCard = adhaarCard;
		this.panCard = panCard;
		this.electricityBill = electricityBill;
		this.drivingLicense = drivingLicense;
		this.voterId = voterId;
		this.user = user;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userdocument_id", nullable = false, unique = true)
	public Integer getdocumentId() {
		return documentId;
	}

	public void setdocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	@Column(name = "aadhaar_card", nullable = false, length = 50)
	public String getAdhaarCard() {
		return adhaarCard;
	}

	public void setAdhaarCard(String adhaarCard) {
		this.adhaarCard = adhaarCard;
	}

	@Column(name = "pan_card", nullable = false, length = 50)
	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	@Column(name = "electricity_bill", nullable = false, length = 50)
	public String getElectricityBill() {
		return electricityBill;
	}

	public void setElectricityBill(String electricityBill) {
		this.electricityBill = electricityBill;
	}

	@Column(name = "driving_license", nullable = false, length = 50)
	public String getDrivingLicense() {
		return drivingLicense;
	}

	public void setDrivingLicense(String drivingLicense) {
		this.drivingLicense = drivingLicense;
	}

	@Column(name = "voter_id", nullable = false, length = 50)
	public String getVoterId() {
		return voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}

	@Column(name = "userImgAadhaarCard", columnDefinition = "longblob")
	public byte[] getUserImgAadhaarCard() {
		return userImgAadhaarCard;
	}

	public void setUserImgAadhaarCard(byte[] userImgAadhaarCard) {
		this.userImgAadhaarCard = userImgAadhaarCard;
	}

	@Column(name = "userImgPanCard", columnDefinition = "longblob")
	public byte[] getUserImgPanCard() {
		return userImgPanCard;
	}

	public void setUserImgPanCard(byte[] userImgPanCard) {
		this.userImgPanCard = userImgPanCard;
	}

	@Column(name = "userImgElectricityBill", columnDefinition = "longblob")
	public byte[] getUserImgElectricityBill() {
		return userImgElectricityBill;
	}

	public void setUserImgElectricityBill(byte[] userImgElectricityBill) {
		this.userImgElectricityBill = userImgElectricityBill;
	}

	@Column(name = "userImgDrivingLicense", columnDefinition = "longblob")
	public byte[] getUserImgDrivingLicense() {
		return userImgDrivingLicense;
	}

	public void setUserImgDrivingLicense(byte[] userImgDrivingLicense) {
		this.userImgDrivingLicense = userImgDrivingLicense;
	}

	@Column(name = "userImgVoterId", columnDefinition = "longblob")
	public byte[] getUserImgVoterId() {
		return userImgVoterId;
	}

	public void setUserImgVoterId(byte[] userImgVoterId) {
		this.userImgVoterId = userImgVoterId;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "fk_user_id")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Documents [adhaarCard=" + adhaarCard + ", panCard=" + panCard + ", electricityBill=" + electricityBill
				+ ", drivingLicense=" + drivingLicense + ", voterId=" + voterId + "]";
	}

}