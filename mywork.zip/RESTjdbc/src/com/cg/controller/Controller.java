package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.DtiProductDaoImp;
import com.cg.dao.EmployeeDao;
import com.cg.pojo.Dti_product;
import com.cg.pojo.Employee;

@RestController
@RequestMapping("/product")
public class Controller {

	@Autowired
	private DtiProductDaoImp dao;

	@Autowired
	private EmployeeDao edao;
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public ResponseEntity<?> getSummary(@PathVariable String id) throws Exception {
		System.out.println("inside get summary method");
		Dti_product p = dao.getPdt(id);
		return new ResponseEntity<Dti_product>(p, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getjson", method=RequestMethod.GET)
	public ResponseEntity<?> get() throws Exception{
		List<Employee> e=edao.getAllDetails();
		return new ResponseEntity<Employee>((Employee) e,HttpStatus.OK);
		
	}
	
}