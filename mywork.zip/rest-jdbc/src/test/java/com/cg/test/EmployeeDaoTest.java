package com.cg.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cg.dao.EmployeeDao;
import com.cg.pojo.Employee;

public class EmployeeDaoTest {
	EmployeeDao dao = new EmployeeDao();

	@Test
	public void testGetAllDetails() {
		List<Employee> empList = dao.getAllDetails();
		assertNotNull(empList);
	}

	@Test
	public void testGetText() {
		String s = dao.getText();
		assertNotNull(s);
	}
}
