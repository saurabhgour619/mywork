package com.cg.test;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import com.cg.dao.DtiProductDaoImp;
import com.cg.pojo.Dti_product;
import com.cg.utils.DBUtils;

public class DtiProductDaoImpTest {

	@Mock
	DBUtils db;

	@Mock
	Connection cn;

	@Mock
	PreparedStatement preparedStatement;

	@Mock
	private ResultSet rs;

	@Before
	public void setUp() throws Exception {
		assertNotNull(db);
		
		when(cn.prepareStatement(any(String.class))).thenReturn(preparedStatement);
		when(DBUtils.getConnection()).thenReturn(cn);

		Dti_product prod = new Dti_product();
		prod.setPdt_code("ABC123");
		prod.setPdt_name("ABC");
		prod.setPdt_desc("DUMMY");
		prod.setPrinted_price(1000d);

		when(rs.getString(1)).thenReturn(prod.getPdt_code());
		when(rs.getString(2)).thenReturn(prod.getPdt_name());
		when(rs.getString(3)).thenReturn(prod.getPdt_desc());
		when(rs.getDouble(4)).thenReturn(prod.getPrinted_price());
		when(preparedStatement.executeQuery()).thenReturn(rs);
	}

	@Test
	public void testGetPdt() throws Exception {
		
		DtiProductDaoImp dtiProductDaoImp = new DtiProductDaoImp();
		Dti_product dti_product = dtiProductDaoImp.getPdt("ABC123");
		assertNotNull(dti_product);

	}
}
