package com.cg.dao;

import com.cg.pojo.Dti_product;

public interface DtiProductDaoInf {
	Dti_product getPdt(String id) throws Exception;
}
