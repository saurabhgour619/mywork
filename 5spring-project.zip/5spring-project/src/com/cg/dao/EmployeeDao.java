package com.cg.dao;

import java.util.List;

import com.cg.pojos.Employee;

public interface EmployeeDao {
	public List<Employee> getAllEmployees();

	public void addEmployee(Employee employee);

	public String deleteEmployee(Employee e);

	public String updateEmployee(Employee e);

	public Employee getEmployee(int employeeid);
}
