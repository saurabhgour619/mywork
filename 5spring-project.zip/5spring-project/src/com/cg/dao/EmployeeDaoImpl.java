package com.cg.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.pojos.Employee;

@Repository
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private SessionFactory sf;

	// add employee
	public void addEmployee(Employee employee) {
		sf.getCurrentSession().saveOrUpdate(employee);
	}

	// get all employee
	@Override
	public List<Employee> getAllEmployees() {
		return sf.getCurrentSession().createQuery("from Employee", Employee.class).getResultList();
	}

	// update a particular employee
	@Override
	public String updateEmployee(Employee e) {
		sf.getCurrentSession().update(e);
		return "Employee with id:	" + e.getId() + "updated successfully";
	}

	// delete employee
	@Override
	public String deleteEmployee(Employee e) {
		sf.getCurrentSession().delete(e);
		return "Employee with id: " + e.getId() + "deleted successfully";
	}

	// get particular employee
	public Employee getEmployee(int id) {
		return sf.getCurrentSession().get(Employee.class, id);
	}

}
